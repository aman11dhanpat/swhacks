require('./').registerAll();
